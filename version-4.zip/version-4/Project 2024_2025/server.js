// Βιβλιοθήκες
const express = require('express');
const mysql = require('mysql2');
const dotenv = require('dotenv');
const path = require('path');
const { Builder } = require('xml2js');
const bodyParser = require('body-parser'); // Για parse των δεδομένων του POST request
const multer = require('multer'); // Για διαχείριση αρχείων
const fs = require('fs');
const session = require('express-session');
const xmlbuilder = require('xmlbuilder');

// Φορτώνουμε τις μεταβλητές
dotenv.config();

// Δημιουργούμε instance του Express
const app = express();

// Για να επεξεργαστούμε τα αιτήματα με JSON
app.use(express.json());

// Για επεξεργασία δεδομένων από τη φόρμα
app.use(bodyParser.urlencoded({ extended: true }));
// Για τη διαχείριση της `req.body` στις φόρμες
app.use(bodyParser.urlencoded({ extended: true }));

// Στατική εξυπηρέτηση αρχείων (αν χρειάζεσαι εικόνες ή CSS)
app.use(express.static(path.join(__dirname, 'src')));

// Ρύθμιση του Multer για ανέβασμα αρχείων
const upload = multer({ dest: 'uploads/' }); // Τα αρχεία θα αποθηκεύονται προσωρινά στον φάκελο uploads

// Σύνδεση με την MySQL
const db = mysql.createConnection({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME
});
const cors = require('cors');
app.use(cors());

app.use(express.static('public'));
// Έλεγχος σύνδεσης με τη βάση δεδομένων
db.connect((err) => {
    if (err) {
        console.error('Σφάλμα σύνδεσης με τη βάση δεδομένων:', err);
        return;
    }
    console.log('Επιτυχής σύνδεση με τη βάση δεδομένων!');
});

// Ρύθμιση του session για να αποθηκεύουμε τα δεδομένα του χρήστη
app.use(session({
    secret: 'your-secret-key', // Μυστικό κλειδί για την κρυπτογράφηση των sessions
    resave: false, // Αποφυγή ανανέωσης του session αν δεν αλλάξει
    saveUninitialized: false, // Μη αποθήκευση κενών sessions
    cookie: {
        maxAge: 24 * 60 * 60 * 1000,  //Διάρκεια ζωής cookie 1 ώρα σε milliseconds 
        httpOnly: true, // Αποτρέπει την πρόσβαση στα cookies από το JavaScript
        secure: false // true θα είναι μόνο αν χρησιμοποιείς HTTPS
    }
}));

app.use((req, res, next) => {
    res.set('Cache-Control', 'no-store, no-cache, must-revalidate, private');
    res.set('Pragma', 'no-cache');
    res.set('Expires', '0');
    next();
});

function checkAuth(role) {
    return (req, res, next) => {
        if (!req.session.user_id || req.session.role !== role) {
            return res.redirect('/'); // Αν δεν έχει συνδεθεί ή έχει λάθος ρόλο, επιστροφή στο login
        }
        next(); // Συνεχίζει στο επόμενο middleware ή route
    };
}

// Get Routes
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'src', 'login.html'));
});

app.get('/Announcement_Endpoint', (req, res) => {
  res.sendFile(path.join(__dirname, 'src', 'announcement_endpoint.html'));
});

app.get('/student', checkAuth('student'), (req, res) => {
    res.sendFile(path.join(__dirname, 'src', 'student.html'));
});

app.get('/Student/Profile', checkAuth('student'), (req, res) => {
    res.sendFile(path.join(__dirname, 'src', 'student_profile.html'));
});

app.get('/Student/Thesis_Management', checkAuth('student'), (req, res) => {
    res.sendFile(path.join(__dirname, 'src', 'student_thesis_management.html'));
});

//route που διαχειρίζεται μόνο την προβολή της HTML σελίδας του /student/view_thesis
app.get('/student/view_thesis', checkAuth('student'), (req, res) => {
    res.sendFile(path.join(__dirname, 'src', 'student_view_thesis.html'));
});

//route που παρέχει τα δεδομένα της διπλωματικής
app.get('/student/view_thesis/data', checkAuth('student'), (req, res) => {
    const userId = req.session.user_id;

    const query = `
        SELECT t.title, t.description, t.pdf_file_path, t.status, t.start_date,
               CONCAT(p1.name, ' ', p1.surname) AS professor1,
               CONCAT(p2.name, ' ', p2.surname) AS professor2,
               CONCAT(p3.name, ' ', p3.surname) AS professor3
        FROM Thesis t
        LEFT JOIN Committee c1 ON t.thesis_id = c1.thesis_id AND c1.role = 'supervisor'
        LEFT JOIN Professors p1 ON c1.professor_id = p1.professor_id
        LEFT JOIN Committee c2 ON t.thesis_id = c2.thesis_id AND c2.role = 'member'
        LEFT JOIN Professors p2 ON c2.professor_id = p2.professor_id
        LEFT JOIN Committee c3 ON t.thesis_id = c3.thesis_id AND c3.role = 'member'
        LEFT JOIN Professors p3 ON c3.professor_id = p3.professor_id
        WHERE t.student_id = ?`;

    db.query(query, [userId], (err, results) => {
        if (err) {
            console.error('Σφάλμα κατά την ανάκτηση της διπλωματικής:', err);
            return res.status(500).json({ error: 'Σφάλμα στον server' });
        }

        if (results.length === 0) {
            return res.status(404).json({ error: 'Δεν βρέθηκε διπλωματική εργασία.' });
        }

        const thesis = results[0];
        const today = new Date();
        const start_date = new Date(thesis.start_date);
        const elapsedDays = Math.floor((today - start_date) / (1000 * 60 * 60 * 24));

        res.json({
            ...thesis,
            elapsedDays
        });
    });
});

app.get('/professor', checkAuth('professor'), (req, res) => {
    res.sendFile(path.join(__dirname, 'src', 'professor.html'));
});

app.get('/professor/view_list_of_thesis', checkAuth('professor'), (req, res) => {
    res.sendFile(path.join(__dirname, 'src', 'professor_view_list_of_thesis.html'));
});

app.get('/professor/initial_assignment', checkAuth('professor'), (req, res) => {
    res.sendFile(path.join(__dirname, 'src', 'professor_initial_assignment.html'));
});

app.get('/professor/view_and_create_thesis_to_assign', checkAuth('professor'), (req, res) => {
    res.sendFile(path.join(__dirname, 'src', 'professor_view_and_create_thesis_to_assign.html'));
});

app.get('/professor/view_committee_invitations', checkAuth('professor'), (req, res) => {
    res.sendFile(path.join(__dirname, 'src', 'professor_view_committee_invitations.html'));
});

app.get('/professor/view_statistics', checkAuth('professor'), (req, res) => {
    res.sendFile(path.join(__dirname, 'src', 'professor_view_statistics.html'));
});

app.get('/secretary', checkAuth('secretary'), (req, res) => {
    res.sendFile(path.join(__dirname, 'src', 'secretary.html'));
});

app.get('/Secretary/View_All_Thesis', checkAuth('secretary'), (req, res) => {
    res.sendFile(path.join(__dirname, 'src', 'secretary_view_all_thesis.html'));
});


app.get('/secretary/view_all_thesis/data', checkAuth('secretary'), (req, res) => {
    const query = `
        SELECT 
     t.thesis_id, 
     t.title, 
     t.description, 
     t.status, 
     t.start_date, 
     t.pdf_file_path,
     (SELECT CONCAT(p.name, ' ', p.surname)
     FROM Committee c 
     LEFT JOIN Professors p ON c.professor_id = p.professor_id
     WHERE c.thesis_id = t.thesis_id AND c.role = 'supervisor') AS professor1,
     (SELECT CONCAT(p.name, ' ', p.surname)
     FROM Committee c 
     LEFT JOIN Professors p ON c.professor_id = p.professor_id
     WHERE c.thesis_id = t.thesis_id AND c.role = 'member' LIMIT 1 OFFSET 0) AS professor2,
     (SELECT CONCAT(p.name, ' ', p.surname)
     FROM Committee c 
     LEFT JOIN Professors p ON c.professor_id = p.professor_id
     WHERE c.thesis_id = t.thesis_id AND c.role = 'member' LIMIT 1 OFFSET 1) AS professor3
     FROM Thesis t
     WHERE t.status IN ('active', 'under_review');`;

    db.query(query, (err, results) => {
        if (err) {
            console.error('Σφάλμα κατά την ανάκτηση των διπλωματικών εργασιών:', err);
            return res.status(500).json({ error: 'Σφάλμα στον server' });
        }

        if (results.length === 0) {
            return res.status(404).json({ error: 'Δεν υπάρχουν ενεργές ή υπό εξέταση διπλωματικές εργασίες.' });
        }

        // Calculate the elapsed days for each thesis
        const today = new Date();
        const theses = results.map(thesis => {
            const start_date = new Date(thesis.start_date);
            const elapsedDays = Math.floor((today - start_date) / (1000 * 60 * 60 * 24));

            return {
                ...thesis,
                elapsedDays
            };
        });

        res.json(theses);
    });
});

//route για την προβολή των λεπτομερειών μιας διπλωματικής όταν η γραμματέας επιλέξει μια εργασία
app.get('/secretary/view_thesis/details/:thesisId', checkAuth('secretary'), (req, res) => {
    const thesisId = req.params.thesisId;

    const query = `
        SELECT t.title, t.description, t.status, t.start_date, t.pdf_file_path, 
           GROUP_CONCAT(DISTINCT CONCAT(p.name, ' ', p.surname) SEPARATOR ', ') AS professors
    FROM Thesis t
    LEFT JOIN Committee c ON t.thesis_id = c.thesis_id
    LEFT JOIN Professors p ON c.professor_id = p.professor_id
    WHERE t.thesis_id = ?
    GROUP BY t.thesis_id`;

    db.query(query, [thesisId], (err, results) => {
        if (err) {
            console.error('Σφάλμα κατά την ανάκτηση των λεπτομερειών της διπλωματικής:', err);
            return res.status(500).json({ error: 'Σφάλμα στον server' });
        }

        if (results.length === 0) {
            return res.status(404).json({ error: 'Δεν βρέθηκε διπλωματική εργασία.' });
        }

        const thesis = results[0];
        const today = new Date();
        const start_date = new Date(thesis.start_date);
        const elapsedDays = Math.floor((today - start_date) / (1000 * 60 * 60 * 24));

        res.json({
            ...thesis,
            elapsedDays
        });
    });
});


app.get('/logout', (req, res) => {
    req.session.destroy((err) => {
        if (err) {
            console.error('Σφάλμα κατά την αποσύνδεση:', err);
            return res.status(500).send('Σφάλμα στον server');
        }
        res.clearCookie('connect.sid'); // Καθαρισμός του cookie του session
        res.redirect('/'); // Επιστροφή στη σελίδα login
    });
});

// Post Routes
// Route για το login POST request
app.post('/', (req, res) => {
    const { username, password } = req.body;

    const query = `
        SELECT u.user_id, 
               CASE 
                   WHEN s.student_id IS NOT NULL THEN 'student'
                   WHEN p.professor_id IS NOT NULL THEN 'professor'
                   WHEN sec.secretary_id IS NOT NULL THEN 'secretary'
                   ELSE NULL
               END AS role
        FROM Users u
        LEFT JOIN Students s ON u.user_id = s.student_id
        LEFT JOIN Professors p ON u.user_id = p.professor_id
        LEFT JOIN Secretaries sec ON u.user_id = sec.secretary_id
        WHERE u.username = ? AND u.password = ?`;

    db.query(query, [username, password], (err, results) => {
        if (err) {
            console.error('Σφάλμα κατά την εκτέλεση του query:', err);
            return res.status(500).send('Σφάλμα στον server');
        }

        if (results.length === 0) {
            // Επιστροφή στο login page με το μήνυμα λάθους μέσω query string
            return res.redirect('/?error=true');
        }

        const user = results[0];

        // Αποθήκευση των πληροφοριών του χρήστη στο session
        req.session.user_id = user.user_id;
        req.session.role = user.role;

        // Ανακατεύθυνση ανάλογα με το ρόλο του χρήστη
        if (user.role === 'student') {
            res.redirect('/student');
        } else if (user.role === 'professor') {
            res.redirect('/professor');
        } else if (user.role === 'secretary') {
            res.redirect('/secretary');
        } else {
            res.status(403).send('Δεν έχετε πρόσβαση.');
        }
    });
});


app.post('/Student/Profile', checkAuth('student'), (req, res) => {
    const userId = req.session.user_id; // Get the logged-in student's ID from the session
    const { change_street, change_number, change_city, change_postcode, change_email, change_mobile, change_landline } = req.body;

    // Concatenate the full address
    const fullAddress = `${change_street} ${change_number}, ${change_city}, ${change_postcode}`;

    const query = `
        UPDATE Students
        SET 
            street = ?, 
            number = ?, 
            city = ?, 
            postcode = ?, 
            email = ?, 
            mobile_telephone = ?, 
            landline_telephone = ?
        WHERE student_id = ?`;

    db.query(
        query,
        [change_street, change_number, change_city, change_postcode, change_email, change_mobile, change_landline, userId],
        (err, result) => {
            if (err) {
                console.error('Σφάλμα κατά την ενημέρωση του προφίλ:', err);
                return res.status(500).send('Σφάλμα στον server');
            }

            if (result.affectedRows > 0) {
                res.send('Τα στοιχεία σας ενημερώθηκαν επιτυχώς!');
            } else {
                res.status(400).send('Αποτυχία ενημέρωσης των στοιχείων.');
            }
        }
    );
});


// route για το data entry POST request για ανέβασμα JSON
app.post('/Secretary', checkAuth('secretary'), upload.single('file'), (req, res) => {
    const filePath = req.file.path;

    // Ανάγνωση του αρχείου JSON
    fs.readFile(filePath, 'utf8', (err, data) => {
        if (err) {
            console.error('Σφάλμα στην ανάγνωση του αρχείου:', err);
            return res.status(500).send('Σφάλμα στην επεξεργασία του αρχείου.');
        }

        try {
            const jsonData = JSON.parse(data);

            // Επεξεργασία φοιτητών
            if (jsonData.students && jsonData.students.length > 0) {
                jsonData.students.forEach(student => {
                    const { name, surname, student_number, street, number, city, postcode, father_name, landline_telephone, mobile_telephone, email } = student;

                    // Εισαγωγή στον πίνακα Users
                    db.query('INSERT INTO Users (username, password) VALUES (?, ?)', [email, 'password123'], (err, results) => {
                        if (err) {
                            console.error('Σφάλμα στην εισαγωγή χρήστη:', err);
                            return;
                        }
                        const userId = results.insertId;

                        // Εισαγωγή στον πίνακα Students
                        db.query('INSERT INTO Students (student_id, name, surname, student_number, street, number, city, postcode, father_name, landline_telephone, mobile_telephone, email) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
                            [userId, name, surname, student_number, street, number, city, postcode, father_name, landline_telephone, mobile_telephone, email],
                            (err) => {
                                if (err) {
                                    console.error('Σφάλμα στην εισαγωγή φοιτητή:', err);
                                }
                            });
                    });
                });
            }

            // Επεξεργασία καθηγητών
            if (jsonData.professors && jsonData.professors.length > 0) {
                jsonData.professors.forEach(professor => {
                    const { name, surname, email, topic, landline, mobile, department, university } = professor;

                    // Εισαγωγή στον πίνακα Users
                    db.query('INSERT INTO Users (username, password) VALUES (?, ?)', [email, 'password123'], (err, results) => {
                        if (err) {
                            console.error('Σφάλμα στην εισαγωγή χρήστη:', err);
                            return;
                        }
                        const userId = results.insertId;

                        // Εισαγωγή στον πίνακα Professors
                        db.query('INSERT INTO Professors (professor_id, name, surname, email, topic, landline, mobile, department, university) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
                            [userId, name, surname, email, topic, landline, mobile, department, university],
                            (err) => {
                                if (err) {
                                    console.error('Σφάλμα στην εισαγωγή καθηγητή:', err);
                                }
                            });
                    });
                });
            }

            res.send('Επιτυχής εισαγωγή δεδομένων.');
        } catch (err) {
            console.error('Σφάλμα στην επεξεργασία του JSON:', err);
            res.status(400).send('Μη έγκυρο αρχείο JSON.');
        } finally {
            // Διαγραφή του προσωρινού αρχείου
            fs.unlink(filePath, (err) => {
                if (err) {
                    console.error('Σφάλμα στη διαγραφή του αρχείου:', err);
                }
            });
        }
    });
});


// Ρύθμιση του server να ακούει σε συγκεκριμένη πόρτα
const port = process.env.PORT;
app.listen(port, () => {
    console.log(`Ο διακομιστής ακούει στην πόρτα ${port}`);
});

//GET
app.get('/professor/view_and_create_thesis_to_assign/data', checkAuth('professor'), (req, res) => {
  const professorId = req.session.user_id; // user_id = professor_id λόγω foreign key

  const sql = `
    SELECT thesis_id, title, description, status, created_at
    FROM thesis
    WHERE supervisor_id = ?
    ORDER BY created_at DESC
  `;

  db.query(sql, [professorId], (err, results) => {
    if (err) {
      console.error("DB error:", err);
      return res.status(500).json({ error: "Database error" });
    }

    res.json(results);
  });
});

//POST

app.post('/professor/view_and_create_thesis_to_assign/create', checkAuth('professor'), upload.single('pdf'), (req, res) => {
  const professorId = req.session.user_id;
  const { title, description } = req.body;
  const pdfPath = req.file ? `/uploads/${req.file.filename}` : null;

  if (!title || !description) {
    return res.status(400).json({ error: "Missing title or description" });
  }

  const sql = `
    INSERT INTO thesis (title, description, supervisor_id, status, start_date, pdf_file_path)
    VALUES (?, ?, ?, 'under_assignment', CURDATE(), ?)
  `;

  db.query(sql, [title, description, professorId, pdfPath], (err, result) => {
    if (err) {
      console.error("Insert error:", err);
      return res.status(500).json({ error: "Database error" });
    }

    res.json({ message: "Thesis created", thesis_id: result.insertId });
  });
});

app.get('/professor/view_and_create_thesis_to_assign/data', checkAuth('professor'), (req, res) => {
  const professorId = req.session.user_id;

  const sql = `
    SELECT t.thesis_id, t.title, t.description, t.status, t.created_at,
           CASE
             WHEN t.supervisor_id = ? THEN 'supervisor'
             WHEN c.professor_id = ? THEN 'committee'
             ELSE 'unknown'
           END AS role
    FROM thesis t
    LEFT JOIN committee c ON t.thesis_id = c.thesis_id AND c.professor_id = ?
    WHERE t.supervisor_id = ? OR c.professor_id = ?
    GROUP BY t.thesis_id
  `;

  const params = [professorId, professorId, professorId, professorId, professorId];

  db.query(sql, params, (err, results) => {
    if (err) {
      console.error("DB error:", err);
      return res.status(500).json({ error: "Database error" });
    }

    res.json(results);
  });
});


app.post('/professor/thesis/update', checkAuth('professor'), (req, res) => {
  const { thesis_id, title, description, status } = req.body;

  const sql = `
    UPDATE thesis SET title = ?, description = ?, status = ?
    WHERE thesis_id = ?
  `;

  db.query(sql, [title, description, status, thesis_id], (err, result) => {
    if (err) {
      console.error("Update error:", err);
      return res.status(500).json({ error: "DB error" });
    }

    res.json({ success: true });
  });
});


app.get('/professor/view_list_of_thesis/data', checkAuth('professor'), (req, res) => {
  const professorId = req.session.user_id;
  const { role, status } = req.query;

  let sql = `
    SELECT DISTINCT t.thesis_id, t.title, t.status, s.name AS student_name
    FROM thesis t
    LEFT JOIN students s ON t.student_id = s.student_id
    LEFT JOIN committee c ON t.thesis_id = c.thesis_id
  `;

  const whereClauses = [];
  const params = [];

  // Φίλτρο ρόλου
  if (role === 'supervisor') {
    whereClauses.push(`t.supervisor_id = ?`);
    params.push(professorId);
  } else if (role === 'committee') {
    whereClauses.push(`c.professor_id = ?`);
    params.push(professorId);
  } else {
    whereClauses.push(`(t.supervisor_id = ? OR c.professor_id = ?)`);
    params.push(professorId, professorId);
  }

  // Φίλτρο κατάστασης
  if (status && status !== 'all') {
    whereClauses.push(`t.status = ?`);
    params.push(status);
  }

  if (whereClauses.length > 0) {
    sql += ` WHERE ` + whereClauses.join(" AND ");
  }

  db.query(sql, params, (err, results) => {
    if (err) {
      console.error("DB error:", err);
      return res.status(500).json({ error: "Database error" });
    }
    res.json(results);
  });
});


app.get('/professor/view_list_of_thesis/details/:id', checkAuth('professor'), (req, res) => {
  const thesisId = req.params.id;

  const thesisQuery = `
    SELECT t.*, s.name AS student_name
    FROM thesis t
    LEFT JOIN students s ON t.student_id = s.student_id
    WHERE t.thesis_id = ?
  `;

  const committeeQuery = `
    SELECT p.name, c.role, c.status
    FROM committee c
    JOIN professors p ON c.professor_id = p.professor_id
    WHERE c.thesis_id = ?
  `;

  const statusQuery = `
    SELECT previous_status, new_status, change_date
    FROM statuschanges
    WHERE thesis_id = ?
    ORDER BY change_date DESC
  `;

  db.query(thesisQuery, [thesisId], (err, thesisResult) => {
    if (err || thesisResult.length === 0) {
      console.error("Thesis error:", err);
      return res.status(404).json({ error: "Thesis not found" });
    }

    const thesis = thesisResult[0];

    db.query(committeeQuery, [thesisId], (err2, committeeResult) => {
      if (err2) return res.status(500).json({ error: "Committee fetch error" });

        db.query(statusQuery, [thesisId], (err3, statusResult) => {
    if (err3) return res.status(500).json({ error: "Status history error" });

    const getRoleQuery = `
      SELECT 
        CASE 
          WHEN t.supervisor_id = ? THEN 'supervisor'
          WHEN EXISTS (
            SELECT 1 FROM committee c
            WHERE c.thesis_id = t.thesis_id AND c.professor_id = ?
          ) THEN 'committee'
          ELSE 'none'
        END AS role
      FROM thesis t WHERE t.thesis_id = ?
    `;

    db.query(getRoleQuery, [req.session.user_id, req.session.user_id, thesisId], (err4, roleResult) => {
      if (err4) return res.status(500).json({ error: "Error getting role" });

      const role = roleResult[0]?.role || 'none';

      res.json({
      thesis_id: thesis.thesis_id,
      title: thesis.title,
      description: thesis.description,
      status: thesis.status,
      pdf_file_path: thesis.pdf_file_path,
      draft_pdf_path: thesis.draft_pdf_path || null,
      presentation_date: thesis.presentation_date,
      presentation_time: thesis.presentation_time,
      presentation_room: thesis.presentation_room,
      final_grade: thesis.final_grade || null,
      grading_form: thesis.grading_form || null,
      student_name: thesis.student_name || null,
      committee: committeeResult,
      status_changes: statusResult,
      role
    });
    });

      });
    });
  });
});

app.post('/professor/thesis/cancel_assignment', checkAuth('professor'), (req, res) => {
  const professorId = req.session.user_id;
  const { thesis_id } = req.body;

  // Βεβαιώσου ότι ο χρήστης είναι supervisor
  const checkQuery = `SELECT * FROM thesis WHERE thesis_id = ? AND supervisor_id = ?`;

  db.query(checkQuery, [thesis_id, professorId], (err, results) => {
    if (err) return res.status(500).json({ error: "DB error (check)" });
    if (results.length === 0) return res.status(403).json({ error: "Not authorized" });

    const thesis = results[0];
    const prevStatus = thesis.status;

    // Πολλαπλά queries: delete committee + invitations, reset student, set status
    const deleteCommittee = `DELETE FROM committee WHERE thesis_id = ?`;
    const deleteInvitations = `DELETE FROM invitations WHERE thesis_id = ?`;
    const updateThesis = `UPDATE thesis SET student_id = NULL, status = 'canceled' WHERE thesis_id = ?`;
const logStatusChange = `INSERT INTO statuschanges (thesis_id, previous_status, new_status) VALUES (?, ?, 'canceled')`;


    db.query(deleteCommittee, [thesis_id], (err1) => {
      if (err1) return res.status(500).json({ error: "DB error (committee)" });

      db.query(deleteInvitations, [thesis_id], (err2) => {
        if (err2) return res.status(500).json({ error: "DB error (invitations)" });

        db.query(updateThesis, [thesis_id], (err3) => {
          if (err3) return res.status(500).json({ error: "DB error (thesis update)" });
            
          db.query(logStatusChange, [thesis_id, prevStatus], (err4) => {
            if (err4) console.warn("Warning: failed to log status change");
            res.json({ message: "Assignment cancelled" });
          });
        });
      });
    });
  });
});


app.post('/professor/thesis/add_note', checkAuth('professor'), (req, res) => {
  const professorId = req.session.user_id;
  const { thesis_id, note_text } = req.body;

  if (!note_text || note_text.length > 300) {
    return res.status(400).json({ error: "Note must be 1-300 characters." });
  }

  const insertQuery = `
    INSERT INTO notes (thesis_id, professor_id, note_text)
    VALUES (?, ?, ?)
  `;

  db.query(insertQuery, [thesis_id, professorId, note_text], (err) => {
    if (err) {
      console.error("DB error inserting note:", err);
      return res.status(500).json({ error: "Database error" });
    }
    res.json({ message: "Note added" });
  });
});
app.get('/professor/thesis/my_notes/:thesis_id', checkAuth('professor'), (req, res) => {
  const professorId = req.session.user_id;
  const thesisId = req.params.thesis_id;

  const query = `
    SELECT note_text, created_at 
    FROM notes
    WHERE thesis_id = ? AND professor_id = ?
    ORDER BY created_at DESC
  `;

  db.query(query, [thesisId, professorId], (err, results) => {
    if (err) return res.status(500).json({ error: "Database error" });
    res.json(results);
  });
});


app.post('/professor/thesis/cancel_active', checkAuth('professor'), (req, res) => {
  const professorId = req.session.user_id;
  const { thesis_id, general_assembly_number, general_assembly_year } = req.body;

  if (!general_assembly_number || !general_assembly_year) {
    return res.status(400).json({ error: "General Assembly number and year required." });
  }

  const checkQuery = `
    SELECT * FROM thesis 
    WHERE thesis_id = ? AND supervisor_id = ? AND status = 'active'
  `;

  db.query(checkQuery, [thesis_id, professorId], (err, results) => {
    if (err) return res.status(500).json({ error: "Database error" });
    if (results.length === 0) return res.status(403).json({ error: "Not authorized or not active." });

    const thesis = results[0];
    const startDate = new Date(thesis.start_date);
    const now = new Date();
    const diffYears = (now - startDate) / (1000 * 60 * 60 * 24 * 365);

    if (diffYears < 2) {
      return res.status(400).json({ error: "Cannot cancel. Less than 2 years have passed." });
    }

    const updateQuery = `UPDATE thesis SET status = 'canceled' WHERE thesis_id = ?`;
    const insertChange = `
      INSERT INTO statuschanges (thesis_id, previous_status, new_status, cancel_reason)
      VALUES (?, 'active', 'canceled', ?)
    `;
    const reason = `Ακύρωση από Διδάσκοντα – Γ.Σ. ${general_assembly_number}/${general_assembly_year}`;

    db.query(updateQuery, [thesis_id], (err2) => {
      if (err2) return res.status(500).json({ error: "Update failed" });

      db.query(insertChange, [thesis_id, reason], (err3) => {
        if (err3) return res.status(500).json({ error: "Log failed" });
        res.json({ message: "Thesis canceled." });
      });
    });
  });
});


app.post('/professor/thesis/set_under_review', checkAuth('professor'), (req, res) => {
  const professorId = req.session.user_id;
  const { thesis_id } = req.body;

  const checkQuery = `
    SELECT * FROM thesis 
    WHERE thesis_id = ? AND supervisor_id = ? AND status = 'active'
  `;

  db.query(checkQuery, [thesis_id, professorId], (err, results) => {
    if (err) return res.status(500).json({ error: "Database error" });
    if (results.length === 0) return res.status(403).json({ error: "Not authorized or not active" });

    const updateQuery = `UPDATE thesis SET status = 'under_review' WHERE thesis_id = ?`;
    const logChange = `
      INSERT INTO statuschanges (thesis_id, previous_status, new_status)
      VALUES (?, 'active', 'under_review')
    `;

    db.query(updateQuery, [thesis_id], (err2) => {
      if (err2) return res.status(500).json({ error: "Status update failed" });

      db.query(logChange, [thesis_id], (err3) => {
        if (err3) return res.status(500).json({ error: "Status change log failed" });
        res.json({ message: "Status updated to under_review" });
      });
    });
  });
});


app.get('/professor/thesis/grades/:id', checkAuth('professor'), (req, res) => {
  const professorId = req.session.user_id;
  const thesisId = req.params.id;

  const query = `
    SELECT p.name, g.grade, g.professor_id
    FROM grades g
    JOIN professors p ON g.professor_id = p.professor_id
    WHERE g.thesis_id = ?
  `;

  db.query(query, [thesisId], (err, results) => {
    if (err) return res.status(500).json({ error: "Database error" });
    res.json(results);
  });
});
app.post('/professor/thesis/submit_grade', checkAuth('professor'), (req, res) => {
  const professorId = req.session.user_id;
  const { thesis_id, grade } = req.body;

  if (grade < 0 || grade > 10) {
    return res.status(400).json({ error: "Grade must be between 0 and 10." });
  }

  const query = `
    INSERT INTO grades (thesis_id, professor_id, grade)
    VALUES (?, ?, ?)
    ON DUPLICATE KEY UPDATE grade = VALUES(grade), submitted_at = CURRENT_TIMESTAMP
  `;

  db.query(query, [thesis_id, professorId, grade], (err) => {
    if (err) return res.status(500).json({ error: "Database error" });
    res.json({ message: "Grade submitted" });
  });
});



app.get('/professor/search_student', checkAuth('professor'), (req, res) => {
  const { search } = req.query;

  const sql = `
    SELECT student_id, name, surname, student_number AS am
    FROM students
    WHERE student_number LIKE ? OR name LIKE ? OR surname LIKE ?
  `;

  const param = `%${search}%`;
  db.query(sql, [param, param, param], (err, results) => {
    if (err) return res.status(500).json({ error: 'Database error' });
    res.json(results);
  });
});
app.get('/professor/get_available_theses', checkAuth('professor'), (req, res) => {
  const professorId = req.session.user_id;

  const sql = `
    SELECT thesis_id, title
    FROM thesis
    WHERE supervisor_id = ? 
      AND student_id IS NULL 
      AND status IN ('under_assignment', 'canceled')
  `;

  db.query(sql, [professorId], (err, results) => {
    if (err) return res.status(500).json({ error: 'Database error' });
    res.json(results);
  });
});

app.post('/professor/assign_thesis', checkAuth('professor'), (req, res) => {
  const professorId = req.session.user_id;
  const { thesis_id, student_id } = req.body;

  // Επιβεβαιώνουμε ότι ο καθηγητής έχει δικαίωμα σε αυτό το θέμα
  const checkQuery = `
    SELECT * FROM thesis 
    WHERE thesis_id = ? AND supervisor_id = ? AND student_id IS NULL AND status = 'under_assignment'
  `;

  db.query(checkQuery, [thesis_id, professorId], (err, results) => {
    if (err) return res.status(500).json({ error: 'Database error' });
    if (results.length === 0) {
      return res.status(403).json({ error: 'Not authorized or thesis already assigned' });
    }

    // Ανάθεση σε φοιτητή
    const updateQuery = `
      UPDATE thesis SET student_id = ?, status = 'under_assignment' WHERE thesis_id = ?
    `;
    const insertCommittee = `
      INSERT INTO committee (thesis_id, professor_id, role, status)
      VALUES (?, ?, 'supervisor', 'accepted')
    `;

    db.query(updateQuery, [student_id, thesis_id], (err2) => {
      if (err2) return res.status(500).json({ error: 'Update failed' });

      db.query(insertCommittee, [thesis_id, professorId], (err3) => {
        if (err3) console.warn("Committee insert warning:", err3); // μπορεί να υπάρχει ήδη
        return res.json({ message: '✅ Thesis assigned to student temporarily' });
      });
    });
  });
});



app.get('/professor/statistics/completion_time', checkAuth('professor'), (req, res) => {
  const professorId = req.session.user_id;

  const sql = `
    SELECT 
      ROUND(AVG(DATEDIFF(end_date, start_date))) AS avg_days, 'supervisor' AS role
    FROM thesis
    WHERE supervisor_id = ? AND status = 'completed'
    UNION
    SELECT 
      ROUND(AVG(DATEDIFF(t.end_date, t.start_date))) AS avg_days, 'committee' AS role
    FROM thesis t
    JOIN committee c ON t.thesis_id = c.thesis_id
    WHERE c.professor_id = ? AND c.role = 'member' AND t.status = 'completed'
  `;

  db.query(sql, [professorId, professorId], (err, results) => {
    if (err) return res.status(500).json({ error: "DB error" });

    const response = { supervisor: 0, committee: 0 };
    results.forEach(r => {
      if (r.role === 'supervisor') response.supervisor = r.avg_days;
      else if (r.role === 'committee') response.committee = r.avg_days;
    });
    res.json(response);
  });
});
app.get('/professor/statistics/avg_grade', checkAuth('professor'), (req, res) => {
  const professorId = req.session.user_id;

  const sql = `
    SELECT ROUND(AVG(g.grade), 2) AS avg_grade, 'supervisor' AS role
    FROM grades g
    JOIN thesis t ON g.thesis_id = t.thesis_id
    WHERE t.supervisor_id = ? AND t.status = 'completed'
    UNION
    SELECT ROUND(AVG(g.grade), 2) AS avg_grade, 'committee' AS role
    FROM grades g
    JOIN committee c ON g.thesis_id = c.thesis_id
    JOIN thesis t ON t.thesis_id = g.thesis_id
    WHERE c.professor_id = ? AND c.role = 'member' AND t.status = 'completed'
  `;

  db.query(sql, [professorId, professorId], (err, results) => {
    if (err) return res.status(500).json({ error: "DB error" });

    const response = { supervisor: 0, committee: 0 };
    results.forEach(r => {
      if (r.role === 'supervisor') response.supervisor = r.avg_grade;
      else if (r.role === 'committee') response.committee = r.avg_grade;
    });
    res.json(response);
  });
});
app.get('/professor/statistics/total_count', checkAuth('professor'), (req, res) => {
  const professorId = req.session.user_id;

  const sql = `
    SELECT COUNT(*) AS total, 'supervisor' AS role
    FROM thesis
    WHERE supervisor_id = ?
    UNION
    SELECT COUNT(*) AS total, 'committee' AS role
    FROM committee
    WHERE professor_id = ? AND role = 'member'
  `;

  db.query(sql, [professorId, professorId], (err, results) => {
    if (err) return res.status(500).json({ error: "DB error" });

    const response = { supervisor: 0, committee: 0 };
    results.forEach(r => {
      if (r.role === 'supervisor') response.supervisor = r.total;
      else if (r.role === 'committee') response.committee = r.total;
    });
    res.json(response);
  });
});



app.get('/professor/invitations', checkAuth('professor'), (req, res) => {
  const professorId = req.session.user_id;

  const sql = `
    SELECT i.invitation_id AS id, t.title AS thesis_title, c.role
    FROM invitations i
    JOIN thesis t ON i.thesis_id = t.thesis_id
    JOIN committee c ON c.thesis_id = t.thesis_id AND c.professor_id = i.professor_id
    WHERE i.professor_id = ? AND i.status = 'pending'
  `;

  db.query(sql, [professorId], (err, results) => {
    if (err) return res.status(500).json({ success: false, message: 'Database error' });
    res.json(results);
  });
});
app.post('/professor/invitations/:id', checkAuth('professor'), (req, res) => {
  const professorId = req.session.user_id;
  const invitationId = req.params.id;
  const { action } = req.body;

  if (!['accept', 'reject'].includes(action)) {
    return res.status(400).json({ success: false, message: 'Invalid action' });
  }

  const newStatus = action === 'accept' ? 'accepted' : 'rejected';

  const sql = `
    UPDATE invitations 
    SET status = ?, response_date = NOW() 
    WHERE invitation_id = ? AND professor_id = ?
  `;

  db.query(sql, [newStatus, invitationId, professorId], (err, result) => {
    if (err) return res.status(500).json({ success: false, message: 'Database error' });

    if (result.affectedRows === 0) {
      return res.status(404).json({ success: false, message: 'Invitation not found or not yours' });
    }

    res.json({ success: true });
  });
});



app.get('/announcements', (req, res) => {
  console.log("✅ GET /announcements called");

  const sql = `
    SELECT 
      tp.date,
      tp.location,
      tp.description,
      t.title
    FROM thesis_presentations tp
    JOIN thesis t ON t.thesis_id = tp.thesis_id
    ORDER BY tp.date DESC
  `;

  db.query(sql, (err, results) => {
    if (err) {
      console.error("❌ DB error in /announcements:", err);
      return res.status(500).json({ error: "Database error" });
    }

    console.log("📦 Returning announcements:", results);
    res.json(results);
  });
});



app.post('/secretary/thesis/approve_assignment', checkAuth('secretary'), (req, res) => {
  const { thesis_id, approval_number } = req.body;
  const sql = `UPDATE thesis SET gs_approval_number = ? WHERE thesis_id = ?`;
  db.query(sql, [approval_number, thesis_id], (err) => {
    if (err) return res.status(500).json({ error: 'DB error' });
    res.json({ message: 'Πρωτόκολλο καταχωρήθηκε' });
  });
});
app.post('/secretary/thesis/cancel', checkAuth('secretary'), (req, res) => {
  const { thesis_id, cancellation_number, reason } = req.body;

  const sql = `UPDATE thesis SET 
    status = 'canceled',
    gs_cancellation_number = ?,
    cancellation_reason = ?
    WHERE thesis_id = ?`;

  db.query(sql, [cancellation_number, reason, thesis_id], (err) => {
    if (err) return res.status(500).json({ error: 'DB error' });
    res.json({ message: 'Ακύρωση ολοκληρώθηκε' });
  });
});
app.post('/secretary/thesis/complete', checkAuth('secretary'), (req, res) => {
    const { thesis_id } = req.body;

    // Έλεγχος αν έχουν ήδη καταχωρηθεί βαθμοί και υπάρχει URL για Νημερτή (pdf_file_path)
    const checkQuery = `
        SELECT final_grade, pdf_file_path FROM thesis
        WHERE thesis_id = ? AND status = 'under_review'
    `;

    db.query(checkQuery, [thesis_id], (err, result) => {
        if (err) return res.status(500).json({ message: 'Database error during check.' });
        if (result.length === 0) return res.status(400).json({ message: 'Invalid thesis or wrong status.' });

        const thesis = result[0];
        if (!thesis.final_grade || !thesis.pdf_file_path) {
            return res.status(400).json({ message: 'Cannot complete thesis: Missing grade or uploaded document.' });
        }

        // Ενημέρωση κατάστασης
        const updateQuery = `
            UPDATE thesis SET status = 'completed' WHERE thesis_id = ?
        `;
        const logStatusChange = `
            INSERT INTO statuschanges (thesis_id, previous_status, new_status)
            VALUES (?, 'under_review', 'completed')
        `;

        db.query(updateQuery, [thesis_id], (err2) => {
            if (err2) return res.status(500).json({ message: 'Error updating thesis.' });

            db.query(logStatusChange, [thesis_id], (err3) => {
                if (err3) console.warn('Could not log status change.');

                res.json({ message: 'Thesis marked as completed.' });
            });
        });
    });
});



app.get('/student/profile/data', checkAuth('student'), (req, res) => {
    const studentId = req.session.user_id;

    const sql = `
        SELECT street, number, city, postcode, email, mobile_telephone AS mobile, landline_telephone AS landline
        FROM students
        WHERE student_id = ?
    `;

    db.query(sql, [studentId], (err, results) => {
        if (err) {
            console.error("DB error:", err);
            return res.status(500).json({ error: "Database error" });
        }

        if (results.length === 0) {
            return res.status(404).json({ error: "Student not found" });
        }

        res.json(results[0]);
    });
});




app.get('/student/thesis/details', checkAuth('student'), (req, res) => {
  const studentId = req.session.user_id;

  const thesisQuery = `
    SELECT t.*, GROUP_CONCAT(p.name SEPARATOR ', ') AS committee_names
    FROM thesis t
    LEFT JOIN committee c ON t.thesis_id = c.thesis_id
    LEFT JOIN professors p ON p.professor_id = c.professor_id
    WHERE t.student_id = ?
    GROUP BY t.thesis_id
  `;

  db.query(thesisQuery, [studentId], (err, results) => {
    if (err) return res.status(500).json({ error: "DB error" });
    if (results.length === 0) return res.status(404).json({ error: "Thesis not found" });

    const thesis = results[0];

    const committeeQuery = `
      SELECT p.name, c.role
      FROM committee c
      JOIN professors p ON c.professor_id = p.professor_id
      WHERE c.thesis_id = ?
    `;

    db.query(committeeQuery, [thesis.thesis_id], (err2, committee) => {
      if (err2) return res.status(500).json({ error: "DB error" });

      res.json({
        title: thesis.title,
        status: thesis.status,
        description: thesis.description,
        committee: committee
      });
    });
  });
});
app.get('/professors/search', checkAuth('student'), (req, res) => {
  const name = `%${req.query.name}%`;
  db.query(
    `SELECT professor_id, name FROM professors WHERE name LIKE ? LIMIT 10`,
    [name],
    (err, results) => {
      if (err) return res.status(500).json({ error: "DB error" });
      res.json(results);
    }
  );
});
app.post('/student/thesis/invite', checkAuth('student'), (req, res) => {
  const studentId = req.session.user_id;
  const professorId = req.body.professor_id;

  const getThesisId = `SELECT thesis_id FROM thesis WHERE student_id = ? AND status = 'under_assignment'`;

  db.query(getThesisId, [studentId], (err, result) => {
    if (err || result.length === 0) return res.status(400).json({ error: "No thesis found" });

    const thesisId = result[0].thesis_id;

    db.query(
      `INSERT IGNORE INTO invitations (thesis_id, professor_id, status, sent_date) VALUES (?, ?, 'pending', NOW())`,
      [thesisId, professorId],
      (err2) => {
        if (err2) return res.status(500).json({ error: "Insert error" });
        res.json({ message: "Invitation sent" });
      }
    );
  });
});
app.get('/student/thesis/invitations', checkAuth('student'), (req, res) => {
  const studentId = req.session.user_id;

  const query = `
    SELECT i.status, p.name
    FROM invitations i
    JOIN professors p ON i.professor_id = p.professor_id
    JOIN thesis t ON i.thesis_id = t.thesis_id
    WHERE t.student_id = ?
  `;

  db.query(query, [studentId], (err, results) => {
    if (err) return res.status(500).json({ error: "DB error" });
    res.json(results);
  });
});
app.post('/student/thesis/set_presentation_info', checkAuth('student'), (req, res) => {
  const { date, time, mode, location, link } = req.body;
  const studentId = req.session.user_id;

  const query = `
    UPDATE thesis
    SET presentation_date = ?, presentation_time = ?, presentation_mode = ?, presentation_room = ?, presentation_link = ?
    WHERE student_id = ?
  `;

  db.query(query, [date, time, mode, location, link, studentId], (err) => {
    if (err) return res.status(500).json({ error: "Update error" });
    res.json({ message: "Presentation info saved" });
  });
});
app.post('/student/thesis/set_repository_link', checkAuth('student'), (req, res) => {
  const { repository_link } = req.body;
  const studentId = req.session.user_id;

  const query = `UPDATE thesis SET repository_link = ? WHERE student_id = ?`;

  db.query(query, [repository_link, studentId], (err) => {
    if (err) return res.status(500).json({ error: "DB error" });
    res.json({ message: "Link saved" });
  });
});
app.get('/student/thesis/report', checkAuth('student'), (req, res) => {
  const studentId = req.session.user_id;

  const query = `
    SELECT grading_form
    FROM thesis
    WHERE student_id = ? AND status = 'completed'
  `;

  db.query(query, [studentId], (err, result) => {
    if (err) return res.status(500).send("Error loading report");
    if (result.length === 0 || !result[0].grading_form) return res.send("<p>No report available</p>");

    // Αν είναι path προς HTML αρχείο, το φορτώνουμε
    const fs = require('fs');
    const path = require('path');
    const filePath = path.join(__dirname, 'uploads', result[0].grading_form);

    fs.readFile(filePath, 'utf8', (err2, html) => {
      if (err2) return res.send("<p>Report file not found</p>");
      res.send(html);
    });
  });
});
