// Βιβλιοθήκες
const express = require('express');
const mysql = require('mysql2');
const dotenv = require('dotenv');
const path = require('path');
const bodyParser = require('body-parser'); // Για parse των δεδομένων του POST request
const multer = require('multer'); // Για διαχείριση αρχείων
const fs = require('fs');
const session = require('express-session');

// Φορτώνουμε τις μεταβλητές
dotenv.config();

// Δημιουργούμε instance του Express
const app = express();

// Για να επεξεργαστούμε τα αιτήματα με JSON
app.use(express.json());

// Για επεξεργασία δεδομένων από τη φόρμα
app.use(bodyParser.urlencoded({ extended: true }));
// Για τη διαχείριση της `req.body` στις φόρμες
app.use(bodyParser.urlencoded({ extended: true }));

// Στατική εξυπηρέτηση αρχείων (αν χρειάζεσαι εικόνες ή CSS)
app.use(express.static(path.join(__dirname, 'src')));

// Ρύθμιση του Multer για ανέβασμα αρχείων
const upload = multer({ dest: 'uploads/' }); // Τα αρχεία θα αποθηκεύονται προσωρινά στον φάκελο uploads

// Σύνδεση με την MySQL
const db = mysql.createConnection({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME
});

// Έλεγχος σύνδεσης με τη βάση δεδομένων
db.connect((err) => {
    if (err) {
        console.error('Σφάλμα σύνδεσης με τη βάση δεδομένων:', err);
        return;
    }
    console.log('Επιτυχής σύνδεση με τη βάση δεδομένων!');
});

// Ρύθμιση του session για να αποθηκεύουμε τα δεδομένα του χρήστη
app.use(session({
    secret: 'your-secret-key', // Μυστικό κλειδί για την κρυπτογράφηση των sessions
    resave: false, // Αποφυγή ανανέωσης του session αν δεν αλλάξει
    saveUninitialized: false, // Μη αποθήκευση κενών sessions
    cookie: {
        maxAge: 24 * 60 * 60 * 1000,  //Διάρκεια ζωής cookie 1 ώρα σε milliseconds 
        httpOnly: true, // Αποτρέπει την πρόσβαση στα cookies από το JavaScript
        secure: false // true θα είναι μόνο αν χρησιμοποιείς HTTPS
    }
}));

app.use((req, res, next) => {
    res.set('Cache-Control', 'no-store, no-cache, must-revalidate, private');
    res.set('Pragma', 'no-cache');
    res.set('Expires', '0');
    next();
});

function checkAuth(role) {
    return (req, res, next) => {
        if (!req.session.user_id || req.session.role !== role) {
            return res.redirect('/'); // Αν δεν έχει συνδεθεί ή έχει λάθος ρόλο, επιστροφή στο login
        }
        next(); // Συνεχίζει στο επόμενο middleware ή route
    };
}

// Get Routes
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'src', 'login.html'));
});

app.get('/student', checkAuth('student'), (req, res) => {
    res.sendFile(path.join(__dirname, 'src', 'student.html'));
});

app.get('/Student/Profile', checkAuth('student'), (req, res) => {
    res.sendFile(path.join(__dirname, 'src', 'student_profile.html'));
});

//route που διαχειρίζεται μόνο την προβολή της HTML σελίδας του /student/view_thesis
app.get('/student/view_thesis', checkAuth('student'), (req, res) => {
    res.sendFile(path.join(__dirname, 'src', 'student_view_thesis.html'));
});

//route που παρέχει τα δεδομένα της διπλωματικής
app.get('/student/view_thesis/data', checkAuth('student'), (req, res) => {
    const userId = req.session.user_id;

    const query = `
        SELECT t.title, t.description, t.pdf_file_path, t.status, t.start_date,
               CONCAT(p1.name, ' ', p1.surname) AS professor1,
               CONCAT(p2.name, ' ', p2.surname) AS professor2,
               CONCAT(p3.name, ' ', p3.surname) AS professor3
        FROM Thesis t
        LEFT JOIN Committee c1 ON t.thesis_id = c1.thesis_id AND c1.role = 'supervisor'
        LEFT JOIN Professors p1 ON c1.professor_id = p1.professor_id
        LEFT JOIN Committee c2 ON t.thesis_id = c2.thesis_id AND c2.role = 'member'
        LEFT JOIN Professors p2 ON c2.professor_id = p2.professor_id
        LEFT JOIN Committee c3 ON t.thesis_id = c3.thesis_id AND c3.role = 'member'
        LEFT JOIN Professors p3 ON c3.professor_id = p3.professor_id
        WHERE t.student_id = ?`;

    db.query(query, [userId], (err, results) => {
        if (err) {
            console.error('Σφάλμα κατά την ανάκτηση της διπλωματικής:', err);
            return res.status(500).json({ error: 'Σφάλμα στον server' });
        }

        if (results.length === 0) {
            return res.status(404).json({ error: 'Δεν βρέθηκε διπλωματική εργασία.' });
        }

        const thesis = results[0];
        const today = new Date();
        const start_date = new Date(thesis.start_date);
        const elapsedDays = Math.floor((today - start_date) / (1000 * 60 * 60 * 24));

        res.json({
            ...thesis,
            elapsedDays
        });
    });
});

app.get('/professor', checkAuth('professor'), (req, res) => {
    res.sendFile(path.join(__dirname, 'src', 'professor.html'));
});

app.get('/secretary', checkAuth('secretary'), (req, res) => {
    res.sendFile(path.join(__dirname, 'src', 'secretary.html'));
});

app.get('/Secretary/View_All_Thesis', checkAuth('secretary'), (req, res) => {
    res.sendFile(path.join(__dirname, 'src', 'secretary_view_all_thesis.html'));
});

//route που ανακτούμε τις διπλωματικές εργασίες
app.get('/secretary/view_all_thesis/data', checkAuth('secretary'), (req, res) => {
    const query = `
        SELECT t.thesis_id, t.title, t.description, t.status, t.start_date, t.pdf_file_path,
               CONCAT(p1.name, ' ', p1.surname) AS professor1,
               CONCAT(p2.name, ' ', p2.surname) AS professor2,
               CONCAT(p3.name, ' ', p3.surname) AS professor3
        FROM Thesis t
        LEFT JOIN Committee c1 ON t.thesis_id = c1.thesis_id AND c1.role = 'supervisor'
        LEFT JOIN Professors p1 ON c1.professor_id = p1.professor_id
        LEFT JOIN Committee c2 ON t.thesis_id = c2.thesis_id AND c2.role = 'member'
        LEFT JOIN Professors p2 ON c2.professor_id = p2.professor_id
        LEFT JOIN Committee c3 ON t.thesis_id = c3.thesis_id AND c3.role = 'member'
        LEFT JOIN Professors p3 ON c3.professor_id = p3.professor_id
        WHERE t.status IN ('active', 'under_review')`;

    db.query(query, (err, results) => {
        if (err) {
            console.error('Σφάλμα κατά την ανάκτηση των διπλωματικών εργασιών:', err);
            return res.status(500).json({ error: 'Σφάλμα στον server' });
        }

        if (results.length === 0) {
            return res.status(404).json({ error: 'Δεν υπάρχουν ενεργές ή υπό εξέταση διπλωματικές εργασίες.' });
        }

        // Calculate the elapsed days for each thesis
        const today = new Date();
        const theses = results.map(thesis => {
            const start_date = new Date(thesis.start_date);
            const elapsedDays = Math.floor((today - start_date) / (1000 * 60 * 60 * 24));

            return {
                ...thesis,
                elapsedDays
            };
        });

        res.json(theses);
    });
});

//route για την προβολή των λεπτομερειών μιας διπλωματικής όταν ο χρήστης επιλέξει μια εργασία
app.get('/secretary/view_thesis/details/:thesisId', checkAuth('secretary'), (req, res) => {
    const thesisId = req.params.thesisId;

    const query = `
        SELECT t.title, t.description, t.status, t.start_date, t.pdf_file_path,
               CONCAT(p1.name, ' ', p1.surname) AS professor1,
               CONCAT(p2.name, ' ', p2.surname) AS professor2,
               CONCAT(p3.name, ' ', p3.surname) AS professor3
        FROM Thesis t
        LEFT JOIN Committee c1 ON t.thesis_id = c1.thesis_id AND c1.role = 'supervisor'
        LEFT JOIN Professors p1 ON c1.professor_id = p1.professor_id
        LEFT JOIN Committee c2 ON t.thesis_id = c2.thesis_id AND c2.role = 'member'
        LEFT JOIN Professors p2 ON c2.professor_id = p2.professor_id
        LEFT JOIN Committee c3 ON t.thesis_id = c3.thesis_id AND c3.role = 'member'
        LEFT JOIN Professors p3 ON c3.professor_id = p3.professor_id
        WHERE t.thesis_id = ?`;

    db.query(query, [thesisId], (err, results) => {
        if (err) {
            console.error('Σφάλμα κατά την ανάκτηση των λεπτομερειών της διπλωματικής:', err);
            return res.status(500).json({ error: 'Σφάλμα στον server' });
        }

        if (results.length === 0) {
            return res.status(404).json({ error: 'Δεν βρέθηκε διπλωματική εργασία.' });
        }

        const thesis = results[0];
        const today = new Date();
        const start_date = new Date(thesis.start_date);
        const elapsedDays = Math.floor((today - start_date) / (1000 * 60 * 60 * 24));

        res.json({
            ...thesis,
            elapsedDays
        });
    });
});


app.get('/logout', (req, res) => {
    req.session.destroy((err) => {
        if (err) {
            console.error('Σφάλμα κατά την αποσύνδεση:', err);
            return res.status(500).send('Σφάλμα στον server');
        }
        res.clearCookie('connect.sid'); // Καθαρισμός του cookie του session
        res.redirect('/'); // Επιστροφή στη σελίδα login
    });
});

// Post Routes
// Route για το login POST request
app.post('/', (req, res) => {
    const { username, password } = req.body;

    const query = `
        SELECT u.user_id, 
               CASE 
                   WHEN s.student_id IS NOT NULL THEN 'student'
                   WHEN p.professor_id IS NOT NULL THEN 'professor'
                   WHEN sec.secretary_id IS NOT NULL THEN 'secretary'
                   ELSE NULL
               END AS role
        FROM Users u
        LEFT JOIN Students s ON u.user_id = s.student_id
        LEFT JOIN Professors p ON u.user_id = p.professor_id
        LEFT JOIN Secretaries sec ON u.user_id = sec.secretary_id
        WHERE u.username = ? AND u.password = ?`;

    db.query(query, [username, password], (err, results) => {
        if (err) {
            console.error('Σφάλμα κατά την εκτέλεση του query:', err);
            return res.status(500).send('Σφάλμα στον server');
        }

        if (results.length === 0) {
            // Επιστροφή στο login page με το μήνυμα λάθους μέσω query string
            return res.redirect('/?error=true');
        }

        const user = results[0];

        // Αποθήκευση των πληροφοριών του χρήστη στο session
        req.session.user_id = user.user_id;
        req.session.role = user.role;

        // Ανακατεύθυνση ανάλογα με το ρόλο του χρήστη
        if (user.role === 'student') {
            res.redirect('/student');
        } else if (user.role === 'professor') {
            res.redirect('/professor');
        } else if (user.role === 'secretary') {
            res.redirect('/secretary');
        } else {
            res.status(403).send('Δεν έχετε πρόσβαση.');
        }
    });
});


app.post('/Student/Profile', checkAuth('student'), (req, res) => {
    const userId = req.session.user_id; // Get the logged-in student's ID from the session
    const { change_street, change_number, change_city, change_postcode, change_email, change_mobile, change_landline } = req.body;

    // Concatenate the full address
    const fullAddress = `${change_street} ${change_number}, ${change_city}, ${change_postcode}`;

    const query = `
        UPDATE Students
        SET 
            street = ?, 
            number = ?, 
            city = ?, 
            postcode = ?, 
            email = ?, 
            mobile_telephone = ?, 
            landline_telephone = ?
        WHERE student_id = ?`;

    db.query(
        query,
        [change_street, change_number, change_city, change_postcode, change_email, change_mobile, change_landline, userId],
        (err, result) => {
            if (err) {
                console.error('Σφάλμα κατά την ενημέρωση του προφίλ:', err);
                return res.status(500).send('Σφάλμα στον server');
            }

            if (result.affectedRows > 0) {
                res.send('Τα στοιχεία σας ενημερώθηκαν επιτυχώς!');
            } else {
                res.status(400).send('Αποτυχία ενημέρωσης των στοιχείων.');
            }
        }
    );
});


// route για το data entry POST request για ανέβασμα JSON
app.post('/Secretary', checkAuth('secretary'), upload.single('file'), (req, res) => {
    const filePath = req.file.path;

    // Ανάγνωση του αρχείου JSON
    fs.readFile(filePath, 'utf8', (err, data) => {
        if (err) {
            console.error('Σφάλμα στην ανάγνωση του αρχείου:', err);
            return res.status(500).send('Σφάλμα στην επεξεργασία του αρχείου.');
        }

        try {
            const jsonData = JSON.parse(data);

            // Επεξεργασία φοιτητών
            if (jsonData.students && jsonData.students.length > 0) {
                jsonData.students.forEach(student => {
                    const { name, surname, student_number, street, number, city, postcode, father_name, landline_telephone, mobile_telephone, email } = student;

                    // Εισαγωγή στον πίνακα Users
                    db.query('INSERT INTO Users (username, password) VALUES (?, ?)', [email, 'password123'], (err, results) => {
                        if (err) {
                            console.error('Σφάλμα στην εισαγωγή χρήστη:', err);
                            return;
                        }
                        const userId = results.insertId;

                        // Εισαγωγή στον πίνακα Students
                        db.query('INSERT INTO Students (student_id, name, surname, student_number, street, number, city, postcode, father_name, landline_telephone, mobile_telephone, email) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
                            [userId, name, surname, student_number, street, number, city, postcode, father_name, landline_telephone, mobile_telephone, email],
                            (err) => {
                                if (err) {
                                    console.error('Σφάλμα στην εισαγωγή φοιτητή:', err);
                                }
                            });
                    });
                });
            }

            // Επεξεργασία καθηγητών
            if (jsonData.professors && jsonData.professors.length > 0) {
                jsonData.professors.forEach(professor => {
                    const { name, surname, email, topic, landline, mobile, department, university } = professor;

                    // Εισαγωγή στον πίνακα Users
                    db.query('INSERT INTO Users (username, password) VALUES (?, ?)', [email, 'password123'], (err, results) => {
                        if (err) {
                            console.error('Σφάλμα στην εισαγωγή χρήστη:', err);
                            return;
                        }
                        const userId = results.insertId;

                        // Εισαγωγή στον πίνακα Professors
                        db.query('INSERT INTO Professors (professor_id, name, surname, email, topic, landline, mobile, department, university) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
                            [userId, name, surname, email, topic, landline, mobile, department, university],
                            (err) => {
                                if (err) {
                                    console.error('Σφάλμα στην εισαγωγή καθηγητή:', err);
                                }
                            });
                    });
                });
            }

            res.send('Επιτυχής εισαγωγή δεδομένων.');
        } catch (err) {
            console.error('Σφάλμα στην επεξεργασία του JSON:', err);
            res.status(400).send('Μη έγκυρο αρχείο JSON.');
        } finally {
            // Διαγραφή του προσωρινού αρχείου
            fs.unlink(filePath, (err) => {
                if (err) {
                    console.error('Σφάλμα στη διαγραφή του αρχείου:', err);
                }
            });
        }
    });
});


// Ρύθμιση του server να ακούει σε συγκεκριμένη πόρτα
const port = process.env.PORT;
app.listen(port, () => {
    console.log(`Ο διακομιστής ακούει στην πόρτα ${port}`);
});