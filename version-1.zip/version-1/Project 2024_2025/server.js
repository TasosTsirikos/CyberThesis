// Βιβλιοθήκες
const express = require('express');
const mysql = require('mysql2');
const dotenv = require('dotenv');
const path = require('path');

// Φορτώνουμε τις μεταβλητές
dotenv.config();

// Δημιουργούμε instance του Express
const app = express();
app.use(express.json()); // Για να επεξεργαστούμε τα αιτήματα με JSON

// Σύνδεση με την MySQL
const db = mysql.createConnection({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME
});

// Έλεγχος σύνδεσης με τη βάση δεδομένων
db.connect((err) => {
    if (err) {
        console.error('Σφάλμα σύνδεσης με τη βάση δεδομένων:', err);
        return;
    }
    console.log('Επιτυχής σύνδεση με τη βάση δεδομένων!');
});

// Στατική εξυπηρέτηση αρχείων (αν χρειάζεσαι εικόνες ή CSS)
app.use(express.static(path.join(__dirname, 'src')));


app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'src', 'login.html'));
});

app.get('/SignUp', (req, res) => {
    res.sendFile(path.join(__dirname, 'src', 'signup.html'));
});


// Ρύθμιση του server να ακούει σε συγκεκριμένη πόρτα
const port = process.env.PORT;
app.listen(port, () => {
    console.log(`Ο διακομιστής ακούει στην πόρτα ${port}`);
});